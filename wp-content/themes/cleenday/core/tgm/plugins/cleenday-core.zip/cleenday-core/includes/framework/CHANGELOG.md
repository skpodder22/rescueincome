# WGL Customized Redux Framework Changelog

## 4.1.24
* Change domain name to cleenday-core
* ./class.redux-plugin: 229
* ./redux-core/inc/classes/class-redux-page-render: 144
* ./redux-core/inc/classes/class-redux-output: Custom Typography
* ./redux-core/class-redux-core: 330, 333, 336, 388


* ./redux-core/inc/fields/typography/redux-typography.js
