<?php
/**
 * Template for Header CPT single page
 *
 * @package cleenday-core\includes\post-types
 * @author WebGeniusLab <webgeniuslab@gmail.com>
 * @since 1.0.0
 */

get_header();
