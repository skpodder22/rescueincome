<?php 
//ini_set('display_errors',1);
require_once get_stylesheet_directory().'/inc/registration.php';

require_once get_stylesheet_directory().'/inc/admin/adminMlm.php';

function cleenday_child_enqueue_parent_style() {
   
    $theme   = wp_get_theme( 'cleenday' );
    $version = $theme->get( 'Version' );
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', null, $version );
    wp_enqueue_style( 'child-custom-style', get_stylesheet_directory_uri() . '/css/custom.css', null, $version );
    wp_enqueue_script('wp-themeCustomjs',get_stylesheet_directory_uri() . '/js/custom.js' , array( 'jquery' ));

    wp_enqueue_script('jquery-ui.min', 'https://code.jquery.com/ui/1.12.1/jquery-ui.min.js' , array( 'jquery' ));
    
}
add_action( 'admin_enqueue_scripts', 'load_custom_admin_style' );
function load_custom_admin_style() {
   // wp_register_style( 'admin_custom_css', get_stylesheet_directory_uri() . '/customAdmin.css', false, '1.0.0' );
    //OR
    wp_enqueue_style( 'admin_custom_css', get_stylesheet_directory_uri() . '/css/admin/customAdmin.css', false, '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'cleenday_child_enqueue_parent_style' );
/**check local mail**/
function mailtrap($phpmailer) {
	$phpmailer->isSMTP();
	$phpmailer->Host = 'smtp.mailtrap.io';
	$phpmailer->SMTPAuth = true;
	$phpmailer->Port = 2525;
	$phpmailer->Username = '584b8fa618659b';
	$phpmailer->Password = '89a65193d6526b';
  }
  
  add_action('phpmailer_init', 'mailtrap');

function userRole_update_custom_roles() {
    if ( get_option( 'custom_roles_version' ) < 1 ) {
        add_role( 'custom_user', 'User', array( 'read' => true, 'level_0' => true ) );
        update_option( 'custom_roles_version', 1 );
    }
    remove_role( 'contributor' );
    // 'author'
    // 'Editor'
    // 'contributor'
    
}
add_action( 'init', 'userRole_update_custom_roles' );

//

remove_action('init', 'wpmlm_register_menu');

add_action('init', 'wpmlm_register_menu_nnu');


if ( !function_exists('wp_authenticate') ) :
    function wp_authenticate($username, $password) {
        $username = sanitize_user($username);
        $password = trim($password);
    
        $user = apply_filters('authenticate', null, $username, $password);
    
        if ( $user == null ) {
            // TODO what should the error message be? (Or would these even happen?)
            // Only needed if all authentication handlers fail to return anything.
            $user = new WP_Error('authentication_failed', __('<strong>ERROR</strong>: Invalid username or incorrect password.'));
        } elseif ( get_user_meta( $user->ID, 'has_to_be_activated', true ) != false ) {
            $user = new WP_Error('activation_failed', __('<strong>ERROR</strong>: User is not activated.'));
        }
    
        $ignore_codes = array('empty_username', 'empty_password');
    
        if (is_wp_error($user) && !in_array($user->get_error_code(), $ignore_codes) ) {
            do_action('wp_login_failed', $username);
        }
    
        return $user;
    }
    endif;

    add_filter('authenticate','checkActivationFromMail',20,3);

    function checkActivationFromMail( $user, $username, $password ) {
            if ( $user instanceof WP_User ) {
                return $user;
            }
            
            $user  = get_user_by( 'login', $username );
            
            if(empty($user)){
                $user  = get_user_by( 'email', $username );
            }
            
            if (  $user == false ) {
                
                return $user;
            }
            //var_dump(get_user_meta( $user->ID, 'has_to_be_activated', true ));die();
            if ( $user == null ) {
                $user = new WP_Error('authentication_failed', __('<strong>ERROR</strong>: Invalid username or incorrect password.'));
            } elseif ( get_user_meta( $user->ID, 'has_to_be_activated', true ) != false ) {
                $user = new WP_Error('activation_failed', __('<strong>ERROR</strong>: User is not activated.'));
            }

            $ignore_codes = array('empty_username', 'empty_password');
        
            if (is_wp_error($user) && !in_array($user->get_error_code(), $ignore_codes) ) {
                do_action('wp_login_failed', $username);
            }
        
            return $user;
            
            // if ( ! $user ) {
            //     return new WP_Error(
            //         'invalid_username',
            //         sprintf(
            //             /* translators: %s: User name. */
            //             __( '<strong>Error</strong>: The username <strong>%s</strong> is not registered on this site. If you are unsure of your username, try your email address instead.' ),
            //             $username
            //         )
            //     );
            // }

        }



function wpsd_add_login_message() {
    return '<p class="message">Your account is now activated. You can now able to login with your account credential.</p>';
}
if ( filter_input( INPUT_GET, 'account_active' ) === 'success' ){
    add_filter('login_message', 'wpsd_add_login_message');
}

    