
  jQuery( document ).ready(function() {
    
    // jQuery( "body" ).on( "click",'a[data-logout="logoutLink"]', function(e) {
    //     e.preventDefault();
    //    // logoutLink = JSON.parse(logoutLink);

    //     console.log(logoutLink);
        
    //     return false;
    //     if( logoutLink != ''){

    //         document.location.href = logoutLink;
    //     }
    //   });
  });