<div class="col-md-12 mlm-main-div template" id="mlm-main-div">        
    <?php 
    wpmlm_user_area_nnu();
    ?>    
</div>