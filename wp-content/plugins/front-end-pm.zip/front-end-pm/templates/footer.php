<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
		</div><!--#fep-content -->
	<div id="fep-footer">
	<?php do_action( 'fep_footer_note' ); ?>
	</div><!--#fep-footer -->
</div><!--#fep-wrapper -->
