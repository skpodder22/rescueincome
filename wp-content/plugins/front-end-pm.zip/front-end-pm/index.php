<?php
# Silence is golden.

